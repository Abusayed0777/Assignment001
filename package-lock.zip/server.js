const express = require('express');
const path = require('path');

const app = express();

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));



// Define routes
app.get('/', (req, res) => {
  res.render('home'); // Renders views/home.ejs
});

app.get('/about', (req, res) => {
  res.render('about'); // Renders views/about.ejs
});

app.get('/projects', (req, res) => {
  res.render('projects'); // Renders views/projects.ejs
});

app.get('/services', (req, res) => {
  res.render('services'); // Renders views/services.ejs
});

app.get('/contact', (req, res) => {
  res.render('contact'); // Renders views/contact.ejs
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
